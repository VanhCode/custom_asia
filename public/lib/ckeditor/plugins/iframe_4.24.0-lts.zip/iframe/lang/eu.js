/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'eu', {
	border: 'Erakutsi markoaren ertza',
	noUrl: 'Idatzi iframe-aren URLa, mesedez.',
	scrolling: 'Gaitu korritze-barrak',
	title: 'IFrame-aren propietateak',
	toolbar: 'IFrame-a',
	tabindex: 'Remove from tabindex' // MISSING
} );
