/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'fr', {
	border: 'Afficher la bordure du cadre',
	noUrl: 'Veuillez entrer l\'URL du contenu du cadre',
	scrolling: 'Activer les barres de défilement',
	title: 'Propriétés du cadre de contenu incorporé',
	toolbar: 'Cadre de contenu incorporé',
	tabindex: 'Supprimer de tabindex'
} );
