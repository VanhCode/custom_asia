/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'oc', {
	border: 'Afichar la bordadura del quadre',
	noUrl: 'Entratz l\'URL del contengut del quadre',
	scrolling: 'Activar las barras de desfilament',
	title: 'Proprietats del quadre de contengut incorporat',
	toolbar: 'Quadre de contengut incorporat',
	tabindex: 'Remove from tabindex' // MISSING
} );
