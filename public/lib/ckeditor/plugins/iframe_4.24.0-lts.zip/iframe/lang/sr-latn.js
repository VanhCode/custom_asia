/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'sr-latn', {
	border: 'Prikaži granicu okvira',
	noUrl: 'Unesite iframe URL',
	scrolling: 'Uključi pomerajuće trake',
	title: 'IFrame podešavanje',
	toolbar: 'IFrame',
	tabindex: 'Uklonite sa tabindeksa'
} );
