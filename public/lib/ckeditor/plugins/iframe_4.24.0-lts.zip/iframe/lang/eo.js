/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'eo', {
	border: 'Montri borderon de kadro (frame)',
	noUrl: 'Bonvolu entajpi la retadreson de la ligilo al la enlinia kadro (IFrame)',
	scrolling: 'Ebligi rulumskalon',
	title: 'Atributoj de la enlinia kadro (IFrame)',
	toolbar: 'Enlinia kadro (IFrame)',
	tabindex: 'Remove from tabindex' // MISSING
} );
