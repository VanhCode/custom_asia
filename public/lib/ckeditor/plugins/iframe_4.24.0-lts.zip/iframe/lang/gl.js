/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'gl', {
	border: 'Amosar o bordo do marco',
	noUrl: 'Escriba o enderezo do iframe',
	scrolling: 'Activar as barras de desprazamento',
	title: 'Propiedades do iFrame',
	toolbar: 'IFrame',
	tabindex: 'Eliminar do índice de tabulación'
} );
