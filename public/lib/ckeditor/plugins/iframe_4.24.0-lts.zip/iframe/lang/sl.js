/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'sl', {
	border: 'Pokaži obrobo okvirja',
	noUrl: 'Prosimo, vnesite iframe URL',
	scrolling: 'Omogoči drsnike',
	title: 'Lastnosti IFrame',
	toolbar: 'IFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
