/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'de-ch', {
	border: 'Rahmen anzeigen',
	noUrl: 'Bitte geben Sie die IFrame-URL an',
	scrolling: 'Rollbalken anzeigen',
	title: 'IFrame-Eigenschaften',
	toolbar: 'IFrame',
	tabindex: 'Aus Tab-Reihenfolge entfernen'
} );
