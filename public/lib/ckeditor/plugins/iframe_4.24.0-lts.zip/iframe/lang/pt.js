/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'pt', {
	border: 'Mostrar a borda da Frame',
	noUrl: 'Por favor, digite o URL da iframe',
	scrolling: 'Ativar barras de rolamento',
	title: 'Propriedades da IFrame',
	toolbar: 'IFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
