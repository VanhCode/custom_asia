/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'cy', {
	border: 'Dangos ymyl y ffrâm',
	noUrl: 'Rhowch URL yr iframe',
	scrolling: 'Galluogi bariau sgrolio',
	title: 'Priodweddau IFrame',
	toolbar: 'IFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
