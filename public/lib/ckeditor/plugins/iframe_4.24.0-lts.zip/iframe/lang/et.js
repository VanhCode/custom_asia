/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'et', {
	border: 'Raami äärise näitamine',
	noUrl: 'Vali iframe URLi liik',
	scrolling: 'Kerimisribade lubamine',
	title: 'IFrame omadused',
	toolbar: 'IFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
