/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'fr-ca', {
	border: 'Afficher la bordure du cadre',
	noUrl: 'Veuillez entre l\'URL du IFrame',
	scrolling: 'Activer les barres de défilement',
	title: 'Propriétés du IFrame',
	toolbar: 'IFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
