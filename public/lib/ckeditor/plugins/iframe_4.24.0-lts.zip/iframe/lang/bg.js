/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'bg', {
	border: 'Показва рамка на карето',
	noUrl: 'Моля въведете URL за iFrame',
	scrolling: 'Активира прелистване',
	title: 'IFrame настройки',
	toolbar: 'IFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
