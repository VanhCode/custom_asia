/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'ku', {
	border: 'نیشاندانی لاکێشه بە چوواردەوری چووارچێوە',
	noUrl: 'تکایه ناونیشانی بەستەر بنووسه بۆ چووارچێوه',
	scrolling: 'چالاککردنی هاتووچۆپێکردن',
	title: 'دیالۆگی چووارچێوه',
	toolbar: 'چووارچێوه',
	tabindex: 'Remove from tabindex' // MISSING
} );
