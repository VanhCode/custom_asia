/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'sr', {
	border: 'Прикажи границу оквира',
	noUrl: 'Унесите  iframe УРЛ',
	scrolling: 'Укљзчи померајуће траке.',
	title: 'IFrame подешавање',
	toolbar: 'IFrame',
	tabindex: 'Уклоните са табиндекcа '
} );
