/*
Copyright (c) 2003-2023, CKSource Holding sp. z o.o. All rights reserved.
CKEditor 4 LTS ("Long Term Support") is available under the terms of the Extended Support Model.
*/
CKEDITOR.plugins.setLang( 'iframe', 'ka', {
	border: 'ჩარჩოს გამოჩენა',
	noUrl: 'აკრიფეთ iframe-ის URL',
	scrolling: 'გადახვევის ზოლების დაშვება',
	title: 'IFrame-ის პარამეტრები',
	toolbar: 'IFrame',
	tabindex: 'Remove from tabindex' // MISSING
} );
